import { Authenticator} from "@aws-amplify/ui-react";

const Login = () => {
    return (
        <Authenticator
            hideSignUp={false}
            variation="modal"
            // socialProviders={["amazon"]}
        />
    );
};

export default Login;
