import { Authenticator} from "@aws-amplify/ui-react";

const Login = () => {
    return (
        <Authenticator
            hideSignUp={false}
            passwordless={{
                hiddenAuthMethods: ["SMS_OTP", "WEB_AUTHN"],
                preferredAuthMethod: "PASSWORD",
            }}
            variation="modal"
            // socialProviders={["amazon"]}
        />
    );
};

export default Login;
