
# Demo Development

[TOC]

## App

Let's start by deploying the starter kit app directly to our sandbox account for testing using the [kit CLI](./design.md#kit-cli).

1. From the root directory, run the command `npm run kit`.

    ![cli-welcome](images/cli-welcome.png)

2. Select your sandbox account then **Synthesize CDK Stacks 🗂️** to validate your CDK code.
    - Ideally, there should be no issues at this point.
3. To deploy your app, select **Deploy CDK Stack(s) 🚀**.
4. Select **Yes** to deploy all stacks.
    - If you select **No**, the CLI will allow you to select exactly which stacks you would like to deploy to the target account.

    ![cli-select-stacks.png](images/cli-select-stacks.png)
    - Deployment may take several minutes.

5. Once the deployment completes, open the [CloudFormation console](https://console.aws.amazon.com/cloudformation/home?#/stacks/) then click the stack ending in **frontendDeployment**.
6. Click the **Outputs** tab then the **callbackUrl** to visit your new frontend React app.

    ![react-login](images/react-login.png)

## Frontend

Let's now setup a local server to test the frontend React app locally so you can quickly iterate.

7. Select **Test Frontend Locally 💻**.
8. Once the CLI finishes creating the local environment, click the **local** URL.

    ![cli-local-env](images/cli-local-env.png)
    - You should see the application's login page. Note that any changes made to the app will be reflected locally for you to test.

9. **Press enter to continue** to explore other operations.

- See the [design documentation](./design.md) for an in-depth look at the starter kit.
